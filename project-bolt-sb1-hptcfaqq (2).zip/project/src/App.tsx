import React, { useState, useMemo } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import MonumentGrid from './components/MonumentGrid';
import MonumentDetail from './components/MonumentDetail';
import Footer from './components/Footer';
import { monuments } from './data/monuments';
import { Monument } from './types/Monument';

function App() {
  const [selectedMonument, setSelectedMonument] = useState<Monument | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({ type: '', state: '' });

  const filteredMonuments = useMemo(() => {
    return monuments.filter(monument => {
      const matchesSearch = searchQuery === '' || 
        monument.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        monument.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
        monument.state.toLowerCase().includes(searchQuery.toLowerCase()) ||
        monument.type.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesType = filters.type === '' || monument.type === filters.type;
      const matchesState = filters.state === '' || monument.state === filters.state;

      return matchesSearch && matchesType && matchesState;
    });
  }, [searchQuery, filters]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleFilterChange = (newFilters: { type: string; state: string }) => {
    setFilters(newFilters);
  };

  const handleMonumentClick = (monument: Monument) => {
    setSelectedMonument(monument);
  };

  const handleCloseDetail = () => {
    setSelectedMonument(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onSearch={handleSearch} onFilterChange={handleFilterChange} />
      
      <main>
        <Hero />
        
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Explore Sacred Monuments
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Discover the rich religious heritage of India through our comprehensive collection 
                of temples, mosques, churches, and gurudwaras across West Bengal and beyond.
              </p>
            </div>
            
            <div className="mb-8">
              <div className="flex flex-wrap gap-4 justify-center">
                <div className="bg-orange-100 text-orange-800 px-4 py-2 rounded-full">
                  🕉️ {monuments.filter(m => m.type === 'temple').length} Temples
                </div>
                <div className="bg-green-100 text-green-800 px-4 py-2 rounded-full">
                  🕌 {monuments.filter(m => m.type === 'mosque').length} Mosques
                </div>
                <div className="bg-blue-100 text-blue-800 px-4 py-2 rounded-full">
                  ⛪ {monuments.filter(m => m.type === 'church').length} Churches
                </div>
                <div className="bg-purple-100 text-purple-800 px-4 py-2 rounded-full">
                  🏛️ {monuments.filter(m => m.type === 'gurudwara').length} Gurudwaras
                </div>
              </div>
            </div>

            <MonumentGrid 
              monuments={filteredMonuments} 
              onMonumentClick={handleMonumentClick}
            />
          </div>
        </section>
      </main>

      <Footer />

      {selectedMonument && (
        <MonumentDetail 
          monument={selectedMonument} 
          onClose={handleCloseDetail}
        />
      )}
    </div>
  );
}

export default App;