import React from 'react';
import { MapPin, Clock, Star } from 'lucide-react';
import { Monument } from '../types/Monument';

interface MonumentCardProps {
  monument: Monument;
  onClick: () => void;
}

const MonumentCard: React.FC<MonumentCardProps> = ({ monument, onClick }) => {
  const getTypeColor = (type: string) => {
    switch (type) {
      case 'temple': return 'bg-orange-100 text-orange-800';
      case 'mosque': return 'bg-green-100 text-green-800';
      case 'church': return 'bg-blue-100 text-blue-800';
      case 'gurudwara': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'temple': return '🕉️';
      case 'mosque': return '🕌';
      case 'church': return '⛪';
      case 'gurudwara': return '🏛️';
      default: return '🏛️';
    }
  };

  return (
    <div 
      className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-1"
      onClick={onClick}
    >
      <div className="relative">
        <img 
          src={monument.image} 
          alt={monument.name}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-4 left-4">
          <span className={`px-3 py-1 rounded-full text-sm font-medium ${getTypeColor(monument.type)}`}>
            {getTypeIcon(monument.type)} {monument.type.charAt(0).toUpperCase() + monument.type.slice(1)}
          </span>
        </div>
        <div className="absolute top-4 right-4 bg-white bg-opacity-90 rounded-full p-2">
          <Star className="w-5 h-5 text-yellow-500 fill-current" />
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-2">{monument.name}</h3>
        <div className="flex items-center text-gray-600 mb-3">
          <MapPin size={16} className="mr-1" />
          <span className="text-sm">{monument.city}, {monument.state}</span>
        </div>
        
        <p className="text-gray-700 text-sm mb-4 line-clamp-3">{monument.description}</p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center text-gray-600">
            <Clock size={16} className="mr-1" />
            <span className="text-sm">{monument.openTimings}</span>
          </div>
          <button className="text-amber-600 hover:text-amber-700 font-medium text-sm">
            Learn More →
          </button>
        </div>
      </div>
    </div>
  );
};

export default MonumentCard;