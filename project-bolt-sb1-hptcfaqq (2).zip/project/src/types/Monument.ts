export interface Monument {
  id: string;
  name: string;
  type: 'temple' | 'mosque' | 'church' | 'gurudwara';
  state: string;
  city: string;
  image: string;
  description: string;
  history: string;
  architecture: string;
  significance: string;
  
  // Information Block 1 (Left)
  mainPrasad?: string[];
  openTimings: string;
  prayerTimings?: string;
  otherDeities?: string[];
  amenities: string[];
  festivals: string[];
  marriageServices?: boolean;
  education?: string[];
  daanDakshina?: string[];
  flowersOffered?: string[];
  foodForDevotees?: string;
  videoLinks?: string[];
  
  // Information Block 2 (Right)
  location: {
    coordinates: string;
    googleMapsLink: string;
    weather: string;
    seaLevel: string;
  };
  howToReach: {
    nearestBus: string;
    nearestTrain: string;
    nearestAirport: string;
  };
  nearbyRestaurants: string[];
  hotels: {
    luxury: string[];
    budget: string[];
  };
  nearbyAttractions: {
    religious: string[];
    nonReligious: string[];
  };
  famousLocalFood: string[];
  contactDetails: {
    phone?: string;
    email?: string;
    address: string;
  };
  officialWebsite?: string;
}