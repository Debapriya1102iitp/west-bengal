import React from 'react';
import { Heart, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <img 
                src="/WhatsApp Image 2025-05-25 at 19.50.57_c8490460.jpg" 
                alt="Sanskriti Dharohar" 
                className="h-10 w-auto"
              />
              <div>
                <h3 className="text-xl font-bold">Sanskriti Dharohar</h3>
                <p className="text-gray-400 text-sm">Preserving India's Religious Heritage</p>
              </div>
            </div>
            <p className="text-gray-300 mb-4 max-w-md">
              Dedicated to preserving and sharing the rich religious heritage of India. 
              Explore thousands of sacred monuments with detailed information, travel guides, 
              and cultural insights.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Youtube size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#temples" className="text-gray-300 hover:text-white transition-colors">Temples</a></li>
              <li><a href="#mosques" className="text-gray-300 hover:text-white transition-colors">Mosques</a></li>
              <li><a href="#churches" className="text-gray-300 hover:text-white transition-colors">Churches</a></li>
              <li><a href="#gurudwaras" className="text-gray-300 hover:text-white transition-colors">Gurudwaras</a></li>
              <li><a href="#about" className="text-gray-300 hover:text-white transition-colors">About Us</a></li>
              <li><a href="#contact" className="text-gray-300 hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Us</h4>
            <div className="space-y-3">
              <div className="flex items-center">
                <Mail size={16} className="mr-2 text-amber-500" />
                <span className="text-gray-300 text-sm">info@sanskritidharohar.com</span>
              </div>
              <div className="flex items-center">
                <Phone size={16} className="mr-2 text-amber-500" />
                <span className="text-gray-300 text-sm">+91 98765 43210</span>
              </div>
              <div className="flex items-start">
                <MapPin size={16} className="mr-2 text-amber-500 mt-1" />
                <span className="text-gray-300 text-sm">
                  Heritage Foundation<br />
                  New Delhi, India
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2025 Sanskriti Dharohar. All rights reserved.
            </p>
            <div className="flex items-center text-gray-400 text-sm">
              <span>Made with</span>
              <Heart size={16} className="mx-1 text-red-500 fill-current" />
              <span>for preserving India's heritage</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;