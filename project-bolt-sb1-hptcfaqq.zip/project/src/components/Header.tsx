import React, { useState } from 'react';
import { Search, Menu, X, MapPin, Filter } from 'lucide-react';

interface HeaderProps {
  onSearch: (query: string) => void;
  onFilterChange: (filters: { type: string; state: string }) => void;
}

const Header: React.FC<HeaderProps> = ({ onSearch, onFilterChange }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({ type: '', state: '' });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  const handleFilterChange = (key: string, value: string) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <img 
              src="/WhatsApp Image 2025-05-25 at 19.50.57_c8490460.jpg" 
              alt="Sanskriti Dharohar" 
              className="h-12 w-auto"
            />
            <div>
              <h1 className="text-2xl font-bold text-amber-800">Sanskriti Dharohar</h1>
              <p className="text-sm text-gray-600">Explore India's Religious Heritage</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#home" className="text-gray-700 hover:text-amber-600 transition-colors">Home</a>
            <a href="#temples" className="text-gray-700 hover:text-amber-600 transition-colors">Temples</a>
            <a href="#mosques" className="text-gray-700 hover:text-amber-600 transition-colors">Mosques</a>
            <a href="#churches" className="text-gray-700 hover:text-amber-600 transition-colors">Churches</a>
            <a href="#gurudwaras" className="text-gray-700 hover:text-amber-600 transition-colors">Gurudwaras</a>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Search and Filters */}
        <div className="pb-4">
          <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Search monuments by name, location, or type..."
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
            >
              Search
            </button>
          </form>

          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex items-center space-x-2">
              <Filter size={20} className="text-gray-500" />
              <select
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500"
                value={filters.type}
                onChange={(e) => handleFilterChange('type', e.target.value)}
              >
                <option value="">All Types</option>
                <option value="temple">Temples</option>
                <option value="mosque">Mosques</option>
                <option value="church">Churches</option>
                <option value="gurudwara">Gurudwaras</option>
              </select>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin size={20} className="text-gray-500" />
              <select
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-amber-500"
                value={filters.state}
                onChange={(e) => handleFilterChange('state', e.target.value)}
              >
                <option value="">All States</option>
                <option value="West Bengal">West Bengal</option>
                <option value="Maharashtra">Maharashtra</option>
                <option value="Tamil Nadu">Tamil Nadu</option>
                <option value="Rajasthan">Rajasthan</option>
                <option value="Gujarat">Gujarat</option>
                <option value="Delhi">Delhi</option>
                <option value="Karnataka">Karnataka</option>
                <option value="Kerala">Kerala</option>
                <option value="Punjab">Punjab</option>
                <option value="Uttar Pradesh">Uttar Pradesh</option>
              </select>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4">
            <nav className="flex flex-col space-y-4">
              <a href="#home" className="text-gray-700 hover:text-amber-600 transition-colors">Home</a>
              <a href="#temples" className="text-gray-700 hover:text-amber-600 transition-colors">Temples</a>
              <a href="#mosques" className="text-gray-700 hover:text-amber-600 transition-colors">Mosques</a>
              <a href="#churches" className="text-gray-700 hover:text-amber-600 transition-colors">Churches</a>
              <a href="#gurudwaras" className="text-gray-700 hover:text-amber-600 transition-colors">Gurudwaras</a>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;