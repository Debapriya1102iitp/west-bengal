import React from 'react';
import { Search, MapPin, Calendar, Users } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative bg-gradient-to-br from-amber-50 via-orange-50 to-red-50 py-20">
      <div className="absolute inset-0 bg-black bg-opacity-10"></div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Discover India's
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-600 to-orange-600">
              {' '}Sacred Heritage
            </span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-700 mb-8 max-w-3xl mx-auto">
            Explore detailed information about religious monuments across different states of India. 
            From ancient temples to historic mosques, churches, and gurudwaras.
          </p>
          
          <div className="grid md:grid-cols-4 gap-6 max-w-4xl mx-auto mb-12">
            <div className="bg-white bg-opacity-80 backdrop-blur-sm rounded-lg p-6 shadow-lg">
              <div className="text-orange-600 mb-3">
                <Search size={32} className="mx-auto" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Search & Discover</h3>
              <p className="text-gray-600 text-sm">Find monuments by name, location, or religious type</p>
            </div>
            
            <div className="bg-white bg-opacity-80 backdrop-blur-sm rounded-lg p-6 shadow-lg">
              <div className="text-green-600 mb-3">
                <MapPin size={32} className="mx-auto" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Detailed Locations</h3>
              <p className="text-gray-600 text-sm">Complete travel information and directions</p>
            </div>
            
            <div className="bg-white bg-opacity-80 backdrop-blur-sm rounded-lg p-6 shadow-lg">
              <div className="text-blue-600 mb-3">
                <Calendar size={32} className="mx-auto" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Festival Calendar</h3>
              <p className="text-gray-600 text-sm">Know about festivals and special celebrations</p>
            </div>
            
            <div className="bg-white bg-opacity-80 backdrop-blur-sm rounded-lg p-6 shadow-lg">
              <div className="text-purple-600 mb-3">
                <Users size={32} className="mx-auto" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Community Info</h3>
              <p className="text-gray-600 text-sm">Services, amenities, and visitor facilities</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors shadow-lg">
              Explore Monuments
            </button>
            <button className="border-2 border-amber-600 text-amber-600 hover:bg-amber-600 hover:text-white px-8 py-3 rounded-lg font-semibold transition-colors">
              Suggest New Monument
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;