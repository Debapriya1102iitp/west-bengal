import React from 'react';
import { 
  X, MapPin, Clock, Phone, Globe, Star, Calendar, 
  Users, Gift, Flower, Utensils, GraduationCap, 
  Car, Train, Plane, Hotel, Camera, Heart
} from 'lucide-react';
import { Monument } from '../types/Monument';

interface MonumentDetailProps {
  monument: Monument;
  onClose: () => void;
}

const MonumentDetail: React.FC<MonumentDetailProps> = ({ monument, onClose }) => {
  const getTypeColor = (type: string) => {
    switch (type) {
      case 'temple': return 'bg-orange-500';
      case 'mosque': return 'bg-green-500';
      case 'church': return 'bg-blue-500';
      case 'gurudwara': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 overflow-y-auto">
      <div className="min-h-screen px-4 py-8">
        <div className="max-w-6xl mx-auto bg-white rounded-xl shadow-2xl">
          {/* Header */}
          <div className="relative">
            <img 
              src={monument.image} 
              alt={monument.name}
              className="w-full h-64 md:h-80 object-cover rounded-t-xl"
            />
            <button
              onClick={onClose}
              className="absolute top-4 right-4 bg-white bg-opacity-90 rounded-full p-2 hover:bg-opacity-100 transition-all"
            >
              <X size={24} />
            </button>
            <div className="absolute bottom-4 left-4 bg-white bg-opacity-95 rounded-lg p-4">
              <div className={`inline-block px-3 py-1 rounded-full text-white text-sm font-medium mb-2 ${getTypeColor(monument.type)}`}>
                {monument.type.charAt(0).toUpperCase() + monument.type.slice(1)}
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900">{monument.name}</h1>
              <div className="flex items-center text-gray-600 mt-1">
                <MapPin size={16} className="mr-1" />
                <span>{monument.city}, {monument.state}</span>
              </div>
            </div>
          </div>

          <div className="p-6 md:p-8">
            {/* Main Description */}
            <div className="mb-8">
              <p className="text-lg text-gray-700 leading-relaxed">{monument.description}</p>
            </div>

            {/* History, Architecture, Significance */}
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="bg-amber-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-amber-800 mb-3">History</h3>
                <p className="text-gray-700">{monument.history}</p>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-blue-800 mb-3">Architecture</h3>
                <p className="text-gray-700">{monument.architecture}</p>
              </div>
              <div className="bg-green-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-green-800 mb-3">Significance</h3>
                <p className="text-gray-700">{monument.significance}</p>
              </div>
            </div>

            {/* Two Column Layout */}
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Left Column - Religious Information */}
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 border-b-2 border-amber-500 pb-2">
                  Religious Information
                </h2>

                {/* Timings */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Clock className="text-amber-600 mr-2" size={20} />
                    <h3 className="font-semibold text-gray-900">Timings</h3>
                  </div>
                  <p className="text-gray-700">Open: {monument.openTimings}</p>
                  {monument.prayerTimings && (
                    <p className="text-gray-700">Prayer: {monument.prayerTimings}</p>
                  )}
                </div>

                {/* Main Prasad/Offerings */}
                {monument.mainPrasad && (
                  <div className="bg-orange-50 p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Gift className="text-orange-600 mr-2" size={20} />
                      <h3 className="font-semibold text-gray-900">Main Prasad/Offerings</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {monument.mainPrasad.map((prasad, index) => (
                        <span key={index} className="bg-orange-100 text-orange-800 px-2 py-1 rounded text-sm">
                          {prasad}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Festivals */}
                <div className="bg-purple-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Calendar className="text-purple-600 mr-2" size={20} />
                    <h3 className="font-semibold text-gray-900">Festivals Celebrated</h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {monument.festivals.map((festival, index) => (
                      <span key={index} className="bg-purple-100 text-purple-800 px-2 py-1 rounded text-sm">
                        {festival}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Amenities */}
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Users className="text-blue-600 mr-2" size={20} />
                    <h3 className="font-semibold text-gray-900">Amenities</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {monument.amenities.map((amenity, index) => (
                      <div key={index} className="flex items-center text-sm text-gray-700">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
                        {amenity}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Food for Devotees */}
                {monument.foodForDevotees && (
                  <div className="bg-green-50 p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Utensils className="text-green-600 mr-2" size={20} />
                      <h3 className="font-semibold text-gray-900">Food for Devotees</h3>
                    </div>
                    <p className="text-gray-700">{monument.foodForDevotees}</p>
                  </div>
                )}
              </div>

              {/* Right Column - Travel Information */}
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 border-b-2 border-blue-500 pb-2">
                  Travel Information
                </h2>

                {/* Location */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <MapPin className="text-red-600 mr-2" size={20} />
                    <h3 className="font-semibold text-gray-900">Location Details</h3>
                  </div>
                  <p className="text-gray-700 mb-1">Coordinates: {monument.location.coordinates}</p>
                  <p className="text-gray-700 mb-1">Weather: {monument.location.weather}</p>
                  <p className="text-gray-700 mb-2">Sea Level: {monument.location.seaLevel}</p>
                  <a 
                    href={monument.location.googleMapsLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                  >
                    View on Google Maps →
                  </a>
                </div>

                {/* How to Reach */}
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="font-semibold text-gray-900 mb-3">How to Reach</h3>
                  <div className="space-y-2">
                    <div className="flex items-start">
                      <Train className="text-blue-600 mr-2 mt-1" size={16} />
                      <div>
                        <p className="font-medium text-sm">By Train</p>
                        <p className="text-gray-700 text-sm">{monument.howToReach.nearestTrain}</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <Car className="text-green-600 mr-2 mt-1" size={16} />
                      <div>
                        <p className="font-medium text-sm">By Bus</p>
                        <p className="text-gray-700 text-sm">{monument.howToReach.nearestBus}</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <Plane className="text-purple-600 mr-2 mt-1" size={16} />
                      <div>
                        <p className="font-medium text-sm">By Air</p>
                        <p className="text-gray-700 text-sm">{monument.howToReach.nearestAirport}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Hotels */}
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Hotel className="text-yellow-600 mr-2" size={20} />
                    <h3 className="font-semibold text-gray-900">Accommodation</h3>
                  </div>
                  <div className="grid grid-cols-1 gap-3">
                    <div>
                      <p className="font-medium text-sm text-gray-900">Luxury Hotels</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {monument.hotels.luxury.map((hotel, index) => (
                          <span key={index} className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs">
                            {hotel}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="font-medium text-sm text-gray-900">Budget Options</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {monument.hotels.budget.map((hotel, index) => (
                          <span key={index} className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs">
                            {hotel}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Nearby Attractions */}
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Camera className="text-green-600 mr-2" size={20} />
                    <h3 className="font-semibold text-gray-900">Nearby Attractions</h3>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <p className="font-medium text-sm text-gray-900">Religious Sites</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {monument.nearbyAttractions.religious.map((attraction, index) => (
                          <span key={index} className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">
                            {attraction}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="font-medium text-sm text-gray-900">Other Attractions</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {monument.nearbyAttractions.nonReligious.map((attraction, index) => (
                          <span key={index} className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">
                            {attraction}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Contact Details */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Phone className="text-gray-600 mr-2" size={20} />
                    <h3 className="font-semibold text-gray-900">Contact Information</h3>
                  </div>
                  <p className="text-gray-700 text-sm mb-1">{monument.contactDetails.address}</p>
                  {monument.contactDetails.phone && (
                    <p className="text-gray-700 text-sm mb-1">Phone: {monument.contactDetails.phone}</p>
                  )}
                  {monument.officialWebsite && (
                    <a 
                      href={monument.officialWebsite}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                    >
                      Official Website →
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MonumentDetail;