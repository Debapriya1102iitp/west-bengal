import { Monument } from '../types/Monument';

export const monuments: Monument[] = [
  // TEMPLES
  {
    id: 'tarakeswar-temple',
    name: 'Tarakeswar Temple',
    type: 'temple',
    state: 'West Bengal',
    city: 'Tarakeswar',
    image: 'https://images.pexels.com/photos/3408744/pexels-photo-3408744.jpeg',
    description: 'The Taraknath Temple is dedicated to Lord Shiva and is known as "Baba Dham". It houses a Swayambhu linga and attracts nearly 10 million devotees during the annual Shiva Yatra covering 39 km from Baidyabati.',
    history: 'Built in 1729 AD by Raja Bharamalla Rao. The temple has been a significant pilgrimage site for centuries, with the annual Shiva Yatra being one of the largest religious gatherings in Bengal. The town is ranked as the least polluted city in Central and South Asia in 2023.',
    architecture: 'Traditional Bengali temple architecture with the sacred Dudhpukur pond believed to have spiritual significance. The temple complex showcases classic Shiva temple design elements.',
    significance: 'One of the most important Shiva temples in Bengal, known for its spiritual healing powers and massive annual pilgrimage. The temple serves as a major center for Shaivism in Eastern India.',
    
    mainPrasad: ['Bel Patra', 'Dhatura', 'Milk', 'Honey', 'Ganga Jal'],
    openTimings: '4:00 AM - 10:00 PM',
    prayerTimings: '5:00 AM, 12:00 PM, 6:00 PM',
    amenities: ['Drinking Water', 'Pooja Items Shop', 'Restrooms', 'Prasad Distribution', 'Parking'],
    festivals: ['Maha Shivratri', 'Shravan Month Celebrations', 'Kartik Purnima', 'Shiva Yatra'],
    marriageServices: true,
    education: ['Religious Studies', 'Sanskrit Classes'],
    daanDakshina: ['Cash Donations', 'Food Donations', 'Cloth Donations'],
    flowersOffered: ['Marigold', 'Lotus', 'Bel Leaves'],
    foodForDevotees: 'Free meals during festivals and special occasions',
    
    location: {
      coordinates: '22.89°N 88.02°E',
      googleMapsLink: 'https://maps.google.com/?q=Tarakeswar+Temple',
      weather: 'Tropical wet and dry climate',
      seaLevel: '18 m (59 ft)'
    },
    howToReach: {
      nearestBus: 'Tarakeswar Bus Terminus - largest in Hooghly district with 50+ routes',
      nearestTrain: 'Tarakeswar Railway Station - Howrah-Tarakeswar line (38 daily trains)',
      nearestAirport: 'Netaji Subhas Chandra Bose International Airport, Kolkata (58 km)'
    },
    nearbyRestaurants: ['Local Bengali Restaurants', 'Vegetarian Thali Places', 'Sweet Shops'],
    hotels: {
      luxury: ['Hotel Tarakeswar Palace', 'Heritage Inn'],
      budget: ['Dharamshala', 'Guest Houses', 'Pilgrim Lodges']
    },
    nearbyAttractions: {
      religious: ['Other Shiva Temples', 'Kali Temples'],
      nonReligious: ['Dudhpukur Pond', 'Local Markets', 'Historical Sites']
    },
    famousLocalFood: ['Bengali Sweets', 'Fish Curry', 'Rice Dishes', 'Mishti Doi'],
    contactDetails: {
      phone: '+91-3212-XXXXX',
      address: 'Tarakeswar, Hooghly District, West Bengal 712410',
    }
  },

  {
    id: 'dakshineswar-temple',
    name: 'Dakshineswar Kali Temple',
    type: 'temple',
    state: 'West Bengal',
    city: 'Kolkata',
    image: 'https://images.pexels.com/photos/5214413/pexels-photo-5214413.jpeg',
    description: 'Dedicated to Bhavatarini, a form of goddess Kali, built by Rani Rashmoni in 1855. Famous for its association with Ramakrishna Paramhansa who served as head priest and gained spiritual enlightenment here.',
    history: 'Built in 1855 by Rani Rashmoni, a philanthropist known for her charitable works. The temple gained prominence through Ramakrishna Paramhansa who served as head priest and attracted devotees from around the world.',
    architecture: 'Traditional Bengali temple architecture with twelve Shiva temples along the riverbank, a Radha-Krishna temple, and beautiful riverside location on the Hooghly River.',
    significance: 'Sacred site where Ramakrishna attained spiritual enlightenment, making it a center of modern Hindu spirituality and the birthplace of the Ramakrishna movement.',
    
    mainPrasad: ['Khichuri', 'Sweets', 'Fruits', 'Flowers'],
    openTimings: '7:00 AM - 12:00 PM, 3:30 PM - 9:00 PM',
    prayerTimings: '6:00 AM, 12:00 PM, 6:00 PM, 8:00 PM',
    amenities: ['Drinking Water', 'Shoe Storage', 'Restrooms', 'Prasad Counter', 'Bathing Ghat'],
    festivals: ['Kali Puja', 'Durga Puja', 'Ramakrishna Jayanti', 'Sarada Devi Jayanti'],
    education: ['Ramakrishna Mission Schools', 'Spiritual Discourses'],
    daanDakshina: ['Cash Offerings', 'Food Donations', 'Flower Offerings'],
    flowersOffered: ['Red Hibiscus', 'Marigold', 'Lotus'],
    foodForDevotees: 'Prasad distribution during festivals',
    
    location: {
      coordinates: '22.6553°N 88.3578°E',
      googleMapsLink: 'https://maps.google.com/?q=Dakshineswar+Kali+Temple',
      weather: 'Tropical wet and dry climate',
      seaLevel: '9 m (30 ft)'
    },
    howToReach: {
      nearestBus: 'Dakshineswar Bus Stand - well connected to Kolkata',
      nearestTrain: 'Dakshineswar Railway Station (10-minute walk)',
      nearestAirport: 'Netaji Subhas Chandra Bose International Airport (25 km)'
    },
    nearbyRestaurants: ['Riverside Restaurants', 'Bengali Cuisine', 'Street Food Stalls'],
    hotels: {
      luxury: ['Ramakrishna Mission Guest House', 'Nearby Kolkata Hotels'],
      budget: ['Dharamshala', 'Budget Lodges', 'Guest Houses']
    },
    nearbyAttractions: {
      religious: ['Belur Math', 'Ramakrishna Mission'],
      nonReligious: ['Hooghly River Ghat', 'Botanical Gardens']
    },
    famousLocalFood: ['Hilsa Fish', 'Rosogolla', 'Sandesh', 'Puchka'],
    contactDetails: {
      address: 'Dakshineswar, Kolkata, West Bengal 700076'
    }
  },

  {
    id: 'kalighat-temple',
    name: 'Kalighat Kali Temple',
    type: 'temple',
    state: 'West Bengal',
    city: 'Kolkata',
    image: 'https://images.pexels.com/photos/3408744/pexels-photo-3408744.jpeg',
    description: 'One of the 51 Shakti Peethas, dedicated to goddess Kali. Believed to be where parts of Sati\'s body fell during Lord Shiva\'s Rudra Tandava. The current structure is over 200 years old.',
    history: 'Ancient temple site with the current structure being over 200 years old. The temple has been a major pilgrimage destination for centuries and is deeply rooted in Bengali culture.',
    architecture: 'Traditional Bengali temple architecture with the main sanctum housing the three-eyed Kali idol with a long protruding tongue and four hands.',
    significance: 'One of the most important Shakti Peethas in India, representing the divine feminine power and serving as a major center for Kali worship.',
    
    mainPrasad: ['Red Hibiscus', 'Sweets', 'Fruits'],
    openTimings: '5:00 AM - 2:00 PM, 5:00 PM - 10:30 PM',
    prayerTimings: '6:00 AM, 12:00 PM, 6:00 PM',
    amenities: ['Drinking Water', 'Religious Items Shop', 'Restrooms', 'Eateries'],
    festivals: ['Kali Puja', 'Durga Puja', 'Poila Boishakh'],
    education: ['Religious Studies'],
    daanDakshina: ['Cash Offerings', 'Food Donations'],
    flowersOffered: ['Red Hibiscus', 'Marigold'],
    foodForDevotees: 'Prasad distribution',
    
    location: {
      coordinates: '22.5186°N 88.3426°E',
      googleMapsLink: 'https://maps.google.com/?q=Kalighat+Kali+Temple',
      weather: 'Tropical wet and dry climate',
      seaLevel: '9 m (30 ft)'
    },
    howToReach: {
      nearestBus: 'Kalighat Bus Stand',
      nearestTrain: 'Kalighat Metro Station (walking distance)',
      nearestAirport: 'Netaji Subhas Chandra Bose International Airport (20 km)'
    },
    nearbyRestaurants: ['Bengali Restaurants', 'Sweet Shops', 'Street Food'],
    hotels: {
      luxury: ['Nearby Kolkata Hotels'],
      budget: ['Guest Houses', 'Budget Hotels']
    },
    nearbyAttractions: {
      religious: ['Other Kali Temples'],
      nonReligious: ['Jatin Das Park Metro Station', 'Local Markets']
    },
    famousLocalFood: ['Bengali Sweets', 'Fish Curry', 'Puchka'],
    contactDetails: {
      address: 'Kalighat, Kolkata, West Bengal'
    }
  },

  {
    id: 'tarapith-temple',
    name: 'Tarapith Temple',
    type: 'temple',
    state: 'West Bengal',
    city: 'Tarapith',
    image: 'https://images.pexels.com/photos/5214413/pexels-photo-5214413.jpeg',
    description: 'One of the 108 Shakti Peethas, dedicated to goddess Tara. Associated with the Tantric saint Bamakhepa, who worshipped at the temple and the adjacent cremation grounds.',
    history: 'Ancient Shakti Peetha where Goddess Sati\'s third eye is believed to have fallen. The temple gained prominence through the Tantric saint Bamakhepa in the 19th century.',
    architecture: 'Traditional Bengali temple architecture with the main sanctum and adjacent cremation grounds (Maha Smashan) creating a unique spiritual atmosphere.',
    significance: 'Important Tantric center and Shakti Peetha, known for its association with Bamakhepa and unique spiritual practices.',
    
    mainPrasad: ['Flowers', 'Sweets', 'Fruits'],
    openTimings: '6:00 AM - 2:00 PM, 7:00 PM - 11:00 PM',
    prayerTimings: '6:00 AM, 12:00 PM, 8:00 PM',
    amenities: ['Prasad Distribution', 'Accommodation', 'Local Eateries'],
    festivals: ['Tara Puja', 'Kali Puja', 'Bamakhepa Jayanti'],
    education: ['Tantric Studies'],
    daanDakshina: ['Cash Offerings', 'Food Donations'],
    flowersOffered: ['Red Hibiscus', 'Marigold'],
    foodForDevotees: 'Prasad distribution',
    
    location: {
      coordinates: '24.1333°N 87.7667°E',
      googleMapsLink: 'https://maps.google.com/?q=Tarapith+Temple',
      weather: 'Tropical wet and dry climate',
      seaLevel: '30 m (98 ft)'
    },
    howToReach: {
      nearestBus: 'Tarapith Bus Stand',
      nearestTrain: 'Rampurhat Junction (9 km)',
      nearestAirport: 'Netaji Subhas Chandra Bose International Airport (200 km)'
    },
    nearbyRestaurants: ['Local Eateries', 'Bengali Cuisine'],
    hotels: {
      luxury: ['Heritage Hotels'],
      budget: ['Guest Houses', 'Dharamshala']
    },
    nearbyAttractions: {
      religious: ['Bamakhepa Ashram', 'Maha Smashan'],
      nonReligious: ['Dwarka River', 'Local Markets']
    },
    famousLocalFood: ['Bengali Sweets', 'Local Delicacies'],
    contactDetails: {
      address: 'Tarapith, Birbhum District, West Bengal'
    }
  },

  {
    id: 'belur-math',
    name: 'Belur Math',
    type: 'temple',
    state: 'West Bengal',
    city: 'Howrah',
    image: 'https://images.pexels.com/photos/3408744/pexels-photo-3408744.jpeg',
    description: 'Headquarters of the Ramakrishna Math and Mission, founded by Swami Vivekananda in 1897. The main temple\'s architecture fuses Hindu, Christian, and Islamic motifs, symbolizing religious unity.',
    history: 'Established by Swami Vivekananda in 1897 as the headquarters of the Ramakrishna Math and Mission. It serves as a center for spiritual learning and social service.',
    architecture: 'Unique architectural fusion of Hindu, Christian, and Islamic motifs symbolizing the unity of all religions, designed to represent Swami Vivekananda\'s philosophy.',
    significance: 'Global headquarters of the Ramakrishna movement, promoting religious harmony and social service based on Vedantic principles.',
    
    mainPrasad: ['Fruits', 'Sweets'],
    openTimings: '6:00 AM - 11:30 AM, 4:00 PM - 7:00 PM',
    prayerTimings: '6:00 AM, 12:00 PM, 6:00 PM',
    amenities: ['Ramakrishna Museum', 'Bookstore', 'Limited Accommodation', 'Canteen'],
    festivals: ['Ramakrishna Jayanti', 'Vivekananda Jayanti', 'Durga Puja'],
    education: ['Ramakrishna Mission Schools', 'Spiritual Discourses', 'Vedantic Studies'],
    daanDakshina: ['Cash Donations', 'Educational Support'],
    flowersOffered: ['Lotus', 'Marigold'],
    foodForDevotees: 'Canteen facilities available',
    
    location: {
      coordinates: '22.6321°N 88.3569°E',
      googleMapsLink: 'https://maps.google.com/?q=Belur+Math',
      weather: 'Tropical wet and dry climate',
      seaLevel: '9 m (30 ft)'
    },
    howToReach: {
      nearestBus: 'Belur Math Bus Stand',
      nearestTrain: 'Belur Railway Station / Howrah Junction (6 km)',
      nearestAirport: 'Netaji Subhas Chandra Bose International Airport (25 km)'
    },
    nearbyRestaurants: ['Canteen', 'Nearby Restaurants'],
    hotels: {
      luxury: ['Ramakrishna Mission Guest House'],
      budget: ['Mission Accommodation', 'Nearby Budget Hotels']
    },
    nearbyAttractions: {
      religious: ['Dakshineswar Temple', 'Ramakrishna Mission Centers'],
      nonReligious: ['Hooghly River', 'Botanical Gardens']
    },
    famousLocalFood: ['Simple Vegetarian Food', 'Bengali Cuisine'],
    contactDetails: {
      address: 'Belur, Howrah, West Bengal 711202'
    }
  },

  {
    id: 'mayapur-iskcon',
    name: 'Mayapur ISKCON Temple',
    type: 'temple',
    state: 'West Bengal',
    city: 'Mayapur',
    image: 'https://images.pexels.com/photos/5214413/pexels-photo-5214413.jpeg',
    description: 'World headquarters for ISKCON, considered the birthplace of Sri Chaitanya Mahaprabhu. The Temple of the Vedic Planetarium aims to be one of the largest religious monuments globally.',
    history: 'Established as the world headquarters of ISKCON, built on the birthplace of Sri Chaitanya Mahaprabhu. The temple complex has grown into a major spiritual and cultural center.',
    architecture: 'Modern temple architecture with traditional elements, featuring the grand Temple of the Vedic Planetarium and multiple temple complexes.',
    significance: 'Global center of the Hare Krishna movement and birthplace of Sri Chaitanya Mahaprabhu, promoting Krishna consciousness worldwide.',
    
    mainPrasad: ['Krishna Prasadam', 'Sweets', 'Fruits'],
    openTimings: '4:30 AM - 1:00 PM, 4:00 PM - 8:30 PM',
    prayerTimings: '4:30 AM, 7:00 AM, 12:00 PM, 6:30 PM',
    amenities: ['Guesthouses', 'Restaurants', 'Educational Tours', 'Cultural Programs'],
    festivals: ['Janmashtami', 'Gaura Purnima', 'Ratha Yatra'],
    education: ['Vedic Studies', 'Krishna Consciousness Programs'],
    daanDakshina: ['Cash Donations', 'Service Donations'],
    flowersOffered: ['Tulsi', 'Marigold', 'Lotus'],
    foodForDevotees: 'Free prasadam during meal times',
    
    location: {
      coordinates: '23.4333°N 88.3833°E',
      googleMapsLink: 'https://maps.google.com/?q=Mayapur+ISKCON+Temple',
      weather: 'Tropical wet and dry climate',
      seaLevel: '10 m (33 ft)'
    },
    howToReach: {
      nearestBus: 'Mayapur Bus Stand',
      nearestTrain: 'Krishnanagar City Junction (18 km)',
      nearestAirport: 'Netaji Subhas Chandra Bose International Airport (130 km)'
    },
    nearbyRestaurants: ['ISKCON Restaurants', 'Vegetarian Cafes'],
    hotels: {
      luxury: ['ISKCON Guesthouses', 'Heritage Hotels'],
      budget: ['Ashrams', 'Budget Guesthouses']
    },
    nearbyAttractions: {
      religious: ['Chaitanya Mahaprabhu Birthplace', 'Other ISKCON Centers'],
      nonReligious: ['Ganges-Jalangi Confluence', 'Cultural Centers']
    },
    famousLocalFood: ['Krishna Prasadam', 'Vegetarian Bengali Cuisine'],
    contactDetails: {
      address: 'Mayapur, Nadia District, West Bengal 741313'
    }
  },

  // MOSQUES
  {
    id: 'nakhoda-mosque',
    name: 'Nakhoda Mosque',
    type: 'mosque',
    state: 'West Bengal',
    city: 'Kolkata',
    image: 'https://images.pexels.com/photos/8828598/pexels-photo-8828598.jpeg',
    description: 'The largest and most significant mosque in West Bengal, completed in 1926. Serves as the principal mosque of Kolkata with capacity for 10,000 worshippers.',
    history: 'Commissioned by Haji Zakariah, rebuilt in 1926 by the Kutchi Memon Jamat. Originally two smaller mosques before 1854, rebuilt at a cost of ₹1,500,000.',
    architecture: 'Mughal and Indo-Islamic architecture inspired by Emperor Akbar\'s Mausoleum at Sikandra. Features 27 minarets with the tallest being 46 meters.',
    significance: 'Largest mosque in Eastern India, serving as a cultural and social hub for Kolkata\'s Muslim community.',
    
    openTimings: '5:00 AM - 10:00 PM',
    prayerTimings: 'Fajr: 5:30 AM, Dhuhr: 12:30 PM, Asr: 4:00 PM, Maghrib: 6:00 PM, Isha: 7:30 PM',
    amenities: ['Ablution Facilities', 'Shoe Storage', 'Prayer Mats', 'Islamic Library'],
    festivals: ['Eid-ul-Fitr', 'Eid-ul-Adha', 'Ramadan', 'Muharram'],
    education: ['Zakaria Madrassa', 'Islamic Studies', 'Arabic Classes'],
    daanDakshina: ['Zakat', 'Sadaqah', 'Charity for Poor'],
    
    location: {
      coordinates: '22°34\'35"N 88°21\'21"E',
      googleMapsLink: 'https://maps.google.com/?q=Nakhoda+Mosque+Kolkata',
      weather: 'Tropical wet and dry climate',
      seaLevel: '9 m (30 ft)'
    },
    howToReach: {
      nearestBus: 'Burrabazar Bus Stand (500m)',
      nearestTrain: 'Sealdah Railway Station (3 km)',
      nearestAirport: 'Netaji Subhas Chandra Bose International Airport (20 km)'
    },
    nearbyRestaurants: ['Halal Restaurants', 'Mughlai Cuisine', 'Biryani Houses', 'Street Food'],
    hotels: {
      luxury: ['Park Hotel', 'The Oberoi Grand'],
      budget: ['Budget Hotels in Burrabazar', 'Guest Houses']
    },
    nearbyAttractions: {
      religious: ['Other Historic Mosques', 'Sufi Shrines'],
      nonReligious: ['Burrabazar Market', 'Hooghly River', 'Colonial Architecture']
    },
    famousLocalFood: ['Biryani', 'Kebabs', 'Haleem', 'Sheer Khurma'],
    contactDetails: {
      address: 'Zakaria Street & Rabindra Sarani, Chitpur, Burrabazar, Kolkata'
    }
  },

  {
    id: 'adina-mosque',
    name: 'Adina Mosque',
    type: 'mosque',
    state: 'West Bengal',
    city: 'Malda',
    image: 'https://images.pexels.com/photos/8828598/pexels-photo-8828598.jpeg',
    description: 'Historic royal mosque built during the Bengal Sultanate, constructed in 1373–1375 by Sikandar Shah. Once the largest mosque in the Indian subcontinent.',
    history: 'Built during Sikandar Shah\'s reign, symbolizing Bengal\'s independence and imperial ambitions. Located in Pandua, a royal capital and thriving trade center.',
    architecture: 'Masterpiece of Islamic architecture with Bengali, Arab, Persian, and Byzantine influences. Features 260 pillars, 387 domed bays, and a monumental ribbed barrel vault.',
    significance: 'Testament to the diverse cultural heritage of medieval Bengal, blending Islamic and local traditions. Monument of National Importance.',
    
    openTimings: 'Sunrise to Sunset (Historical Site)',
    amenities: ['Historical Preservation', 'Guided Tours'],
    festivals: ['Historical Commemorations'],
    education: ['Historical Studies', 'Archaeological Research'],
    
    location: {
      coordinates: '25°09\'08"N 88°09\'53"E',
      googleMapsLink: 'https://maps.google.com/?q=Adina+Mosque+Malda',
      weather: 'Tropical wet and dry climate',
      seaLevel: '25 m (82 ft)'
    },
    howToReach: {
      nearestBus: 'Malda Bus Stand (18 km)',
      nearestTrain: 'Malda Town Railway Station (18 km)',
      nearestAirport: 'Bagdogra Airport (200 km)'
    },
    nearbyRestaurants: ['Local Restaurants', 'Bengali Cuisine'],
    hotels: {
      luxury: ['Heritage Hotels in Malda'],
      budget: ['Budget Hotels', 'Guest Houses']
    },
    nearbyAttractions: {
      religious: ['Other Historic Mosques', 'Ancient Temples'],
      nonReligious: ['Archaeological Sites', 'Historical Monuments']
    },
    famousLocalFood: ['Bengali Cuisine', 'Local Delicacies'],
    contactDetails: {
      address: 'Pandua, Malda, West Bengal'
    }
  },

  {
    id: 'tipu-sultan-mosque',
    name: 'Tipu Sultan Mosque (Tollygunge)',
    type: 'mosque',
    state: 'West Bengal',
    city: 'Kolkata',
    image: 'https://images.pexels.com/photos/8828598/pexels-photo-8828598.jpeg',
    description: 'Historic Sunni mosque built between 1852 and 1860, commissioned by Prince Ghulam Mohammed Sultan Sahib, the 11th son of Tipu Sultan.',
    history: 'Built by Prince Ghulam Mohammed after Tipu Sultan\'s family was exiled to Calcutta by the British Government. Part of Ghulam Mohammed\'s contributions to public works in Calcutta.',
    architecture: 'Elegant Indo-Islamic structure with at least six domes and four minarets, featuring intricate Islamic motifs and geometric patterns.',
    significance: 'Symbol of Tipu Sultan\'s legacy and his family\'s enduring presence in Kolkata, preserving Indo-Islamic heritage.',
    
    openTimings: '5:00 AM - 10:00 PM',
    prayerTimings: 'Five daily prayers according to Islamic schedule',
    amenities: ['Prayer Hall', 'Ablution Facilities', 'Community Hall'],
    festivals: ['Eid-ul-Fitr', 'Eid-ul-Adha', 'Eid-ul-Milad-un-Nabi'],
    education: ['Islamic Studies', 'Quranic Education'],
    daanDakshina: ['Zakat', 'Sadaqah'],
    
    location: {
      coordinates: '22°30\'06"N 88°20\'43"E',
      googleMapsLink: 'https://maps.google.com/?q=Tipu+Sultan+Mosque+Tollygunge',
      weather: 'Tropical wet and dry climate',
      seaLevel: '9 m (30 ft)'
    },
    howToReach: {
      nearestBus: 'Tollygunge Bus Stand',
      nearestTrain: 'Tollygunge Metro Station (nearby)',
      nearestAirport: 'Netaji Subhas Chandra Bose International Airport (15 km)'
    },
    nearbyRestaurants: ['Halal Restaurants', 'Local Cuisine'],
    hotels: {
      luxury: ['Nearby Kolkata Hotels'],
      budget: ['Budget Accommodations']
    },
    nearbyAttractions: {
      religious: ['Other Mosques', 'Historical Sites'],
      nonReligious: ['Tollygunge Club', 'Local Markets']
    },
    famousLocalFood: ['Mughlai Cuisine', 'Bengali-Muslim Dishes'],
    contactDetails: {
      address: '135 Prince Anwar Shah Road, Tollygunge, Kolkata'
    }
  },

  // CHURCHES
  {
    id: 'st-pauls-cathedral',
    name: 'St. Paul\'s Cathedral',
    type: 'church',
    state: 'West Bengal',
    city: 'Kolkata',
    image: 'https://images.pexels.com/photos/6210959/pexels-photo-6210959.jpeg',
    description: 'The largest church in Kolkata and the first Anglican cathedral in Asia, completed in 1847. Known for its Indo-Gothic architecture and historical significance.',
    history: 'Completed in 1847, designed to suit India\'s climate. Endured earthquakes in 1897 and 1934 with subsequent reconstruction. Features significant historical artifacts.',
    architecture: 'Indo-Gothic architecture with three stained-glass windows, frescoes in Florentine Renaissance style, and impressive stone work.',
    significance: 'First Anglican cathedral in Asia, representing the colonial Christian heritage of India.',
    
    openTimings: '9:00 AM - 12:00 PM, 3:00 PM - 6:00 PM',
    prayerTimings: 'Sunday Service: 8:00 AM, 10:30 AM; Weekday Services: 7:00 AM',
    amenities: ['Library', 'Seating Arrangements', 'Restrooms', 'Prayer Areas'],
    festivals: ['Christmas', 'Easter', 'Good Friday', 'Harvest Festival'],
    education: ['Sunday School', 'Bible Study', 'Christian Education'],
    
    location: {
      coordinates: '22.5448°N 88.3426°E',
      googleMapsLink: 'https://maps.google.com/?q=St+Paul+Cathedral+Kolkata',
      weather: 'Tropical wet and dry climate',
      seaLevel: '9 m (30 ft)'
    },
    howToReach: {
      nearestBus: 'Maidan Bus Stand (1 km)',
      nearestTrain: 'Sealdah Railway Station (5 km)',
      nearestAirport: 'Netaji Subhas Chandra Bose International Airport (20 km)'
    },
    nearbyRestaurants: ['Park Street Restaurants', 'Continental Cuisine', 'Cafes'],
    hotels: {
      luxury: ['The Oberoi Grand', 'ITC Sonar', 'Taj Bengal'],
      budget: ['YMCA', 'Budget Hotels near Park Street']
    },
    nearbyAttractions: {
      religious: ['Other Historic Churches', 'Mother Teresa\'s House'],
      nonReligious: ['Victoria Memorial', 'Maidan', 'Indian Museum']
    },
    famousLocalFood: ['Continental Dishes', 'Bengali Cuisine', 'Bakery Items'],
    contactDetails: {
      address: '1A, Cathedral Road, Kolkata - 700071'
    }
  },

  {
    id: 'bandel-church',
    name: 'Basilica of the Holy Rosary (Bandel Church)',
    type: 'church',
    state: 'West Bengal',
    city: 'Bandel',
    image: 'https://images.pexels.com/photos/6210959/pexels-photo-6210959.jpeg',
    description: 'One of the oldest Christian churches in West Bengal, founded in 1599 and dedicated to Nossa Senhora do Rosário (Our Lady of the Rosary).',
    history: 'Founded in 1599, burnt down during the sacking of Hooghly by the Mughals in 1632 and rebuilt in 1660. Declared a minor basilica by Pope John Paul II in 1988.',
    architecture: 'Colonial Portuguese architecture with traditional Catholic church design elements.',
    significance: 'One of the oldest Christian establishments in Bengal, representing the early Portuguese missionary activities in India.',
    
    openTimings: 'Early morning until evening daily',
    prayerTimings: 'Daily Mass and Sunday Services',
    amenities: ['Basic Church Facilities', 'Prayer Areas'],
    festivals: ['Christmas', 'Easter', 'Feast of Our Lady of the Rosary'],
    education: ['Religious Education', 'Community Programs'],
    
    location: {
      coordinates: '22.9667°N 88.3833°E',
      googleMapsLink: 'https://maps.google.com/?q=Bandel+Church',
      weather: 'Tropical wet and dry climate',
      seaLevel: '12 m (39 ft)'
    },
    howToReach: {
      nearestBus: 'Bandel Bus Stand',
      nearestTrain: 'Bandel Junction (2 km)',
      nearestAirport: 'Netaji Subhas Chandra Bose International Airport (43 km)'
    },
    nearbyRestaurants: ['Local Restaurants', 'Bengali Cuisine'],
    hotels: {
      luxury: ['Heritage Hotels'],
      budget: ['Guest Houses', 'Budget Hotels']
    },
    nearbyAttractions: {
      religious: ['Other Historic Churches'],
      nonReligious: ['Hooghly River', 'Historical Sites']
    },
    famousLocalFood: ['Bengali Cuisine', 'Portuguese-influenced Dishes'],
    contactDetails: {
      address: 'Bandel, Hooghly District, West Bengal'
    }
  },

  {
    id: 'st-johns-church',
    name: 'St. John\'s Church',
    type: 'church',
    state: 'West Bengal',
    city: 'Kolkata',
    image: 'https://images.pexels.com/photos/6210959/pexels-photo-6210959.jpeg',
    description: 'Consecrated in 1787, one of the first public buildings erected by the East India Company after Kolkata became the capital of British India.',
    history: 'Foundation stone laid by Governor-General Warren Hastings on April 6, 1784. Designed by James Agg, modeled after St. Martin-in-the-Fields in London.',
    architecture: 'Neoclassical architecture with a 174-foot stone spire housing a giant clock. Floor of blue-grey marble and contains "The Last Supper" by Johann Zoffany.',
    significance: 'Historic church representing early British colonial architecture and containing important memorials of the colonial period.',
    
    openTimings: '8:00 AM - 5:00 PM daily',
    prayerTimings: 'Sunday Services and special occasions',
    amenities: ['Guided Tours', 'Informational Plaques', 'Garden', 'Photography Permitted'],
    festivals: ['Christmas', 'Easter', 'Memorial Services'],
    education: ['Historical Tours', 'Colonial History'],
    
    location: {
      coordinates: '22.5626°N 88.3506°E',
      googleMapsLink: 'https://maps.google.com/?q=St+Johns+Church+Kolkata',
      weather: 'Tropical wet and dry climate',
      seaLevel: '9 m (30 ft)'
    },
    howToReach: {
      nearestBus: 'B.B.D. Bagh Bus Stand',
      nearestTrain: 'Esplanade Metro Station (1 km)',
      nearestAirport: 'Netaji Subhas Chandra Bose International Airport (20 km)'
    },
    nearbyRestaurants: ['Central Kolkata Restaurants', 'Colonial-era Cafes'],
    hotels: {
      luxury: ['Heritage Hotels in Central Kolkata'],
      budget: ['Budget Hotels in Central Area']
    },
    nearbyAttractions: {
      religious: ['Other Historic Churches'],
      nonReligious: ['Raj Bhavan', 'Writers\' Building', 'GPO']
    },
    famousLocalFood: ['Colonial-era Cuisine', 'Bengali Dishes'],
    contactDetails: {
      address: '2/2 Council House Street, B.B.D. Bagh, Kolkata'
    }
  },

  // GURUDWARAS
  {
    id: 'gurudwara-bari-sangat',
    name: 'Gurudwara Sri Bari Sangat Sahib',
    type: 'gurudwara',
    state: 'West Bengal',
    city: 'Kolkata',
    image: 'https://images.pexels.com/photos/9166266/pexels-photo-9166266.jpeg',
    description: 'Historic Sikh place of worship visited by both Guru Nanak Sahib Ji and Guru Tegh Bahadur Sahib Ji. Established in memory of Guru Nanak\'s visit in 1510.',
    history: 'Visited by Guru Nanak on January 2, 1510, while returning from Dhaka. The area was suffering from an epidemic, and Guru Nanak\'s presence brought divine healing.',
    architecture: 'Traditional Sikh architecture with main prayer hall, community kitchen, and accommodation facilities.',
    significance: 'One of Kolkata\'s most historic Sikh Gurudwaras, center of Sikh faith and humanitarian service.',
    
    openTimings: '4:00 AM - 10:00 PM',
    prayerTimings: 'Morning: 5:00 AM, Evening: 7:00 PM',
    amenities: ['Langar Hall', 'Library', 'Accommodation', 'Medical Aid'],
    festivals: ['Guru Nanak Jayanti', 'Guru Tegh Bahadur Martyrdom', 'Baisakhi', 'Diwali'],
    education: ['Gurbani Classes', 'Punjabi Language', 'Sikh History'],
    daanDakshina: ['Seva Donations', 'Langar Contributions', 'Educational Support'],
    foodForDevotees: 'Free Langar (community kitchen) for all visitors',
    
    location: {
      coordinates: '22.5734°N 88.3630°E',
      googleMapsLink: 'https://maps.google.com/?q=Gurudwara+Bari+Sangat+Kolkata',
      weather: 'Tropical wet and dry climate',
      seaLevel: '9 m (30 ft)'
    },
    howToReach: {
      nearestBus: 'Barabazar Bus Stand (500m)',
      nearestTrain: 'Howrah Junction (4 km)',
      nearestAirport: 'Netaji Subhas Chandra Bose International Airport (20 km)'
    },
    nearbyRestaurants: ['Punjabi Restaurants', 'Vegetarian Food', 'Langar Hall'],
    hotels: {
      luxury: ['Nearby Kolkata Hotels'],
      budget: ['Gurudwara Accommodation', 'Dharamshala']
    },
    nearbyAttractions: {
      religious: ['Other Gurudwaras', 'Historic Temples'],
      nonReligious: ['Barabazar Market', 'Hooghly River']
    },
    famousLocalFood: ['Punjabi Cuisine', 'Langar Food', 'Vegetarian Thali'],
    contactDetails: {
      address: 'Barabazar Market, Kolkata, West Bengal 700007'
    }
  },

  {
    id: 'gurudwara-sant-kutiya',
    name: 'Gurudwara Sant Kutiya',
    type: 'gurudwara',
    state: 'West Bengal',
    city: 'Kolkata',
    image: 'https://images.pexels.com/photos/9166266/pexels-photo-9166266.jpeg',
    description: 'Significant Sikh place of worship established by Baba Basant Singh Ji. Known for its peaceful ambiance and community services including medical facilities.',
    history: 'Founded by Baba Basant Singh Ji, a revered Sikh saint. Has served as a place for spiritual guidance, community service, and religious teachings.',
    architecture: 'Traditional Sikh architectural style with prayer hall, langar hall, and medical facilities.',
    significance: 'Important center for Sikh community services, combining spiritual practice with healthcare and social welfare.',
    
    openTimings: '4:00 AM - 10:00 PM',
    prayerTimings: 'Morning and Evening prayers',
    amenities: ['Langar Hall', 'Medical Services', 'Prayer Hall', 'Community Programs'],
    festivals: ['Guru Nanak Jayanti', 'Baisakhi', 'Gurpurab Celebrations'],
    education: ['Gurbani Classes', 'Community Education'],
    daanDakshina: ['Medical Aid Donations', 'Langar Contributions'],
    foodForDevotees: 'Free vegetarian meals for all visitors',
    
    location: {
      coordinates: '22.5448°N 88.3426°E',
      googleMapsLink: 'https://maps.google.com/?q=Gurudwara+Sant+Kutiya+Kolkata',
      weather: 'Tropical wet and dry climate',
      seaLevel: '9 m (30 ft)'
    },
    howToReach: {
      nearestBus: 'Harish Mukherjee Road Bus Stop',
      nearestTrain: 'Netaji Bhawan Metro Station (1 km)',
      nearestAirport: 'Netaji Subhas Chandra Bose International Airport (20 km)'
    },
    nearbyRestaurants: ['Vegetarian Restaurants', 'Punjabi Cuisine'],
    hotels: {
      luxury: ['Nearby Kolkata Hotels'],
      budget: ['Guest Houses', 'Budget Accommodations']
    },
    nearbyAttractions: {
      religious: ['Other Gurudwaras', 'Temples'],
      nonReligious: ['Victoria Memorial', 'Eden Gardens', 'Park Street']
    },
    famousLocalFood: ['Punjabi Cuisine', 'Vegetarian Food'],
    contactDetails: {
      phone: '+91 33 2455 2585',
      address: '10A, Harish Mukherjee Road, Bhawanipur, Kolkata 700025'
    }
  },

  {
    id: 'gurudwara-chhota-sangat',
    name: 'Gurudwara Chhota Sikh Sangat',
    type: 'gurudwara',
    state: 'West Bengal',
    city: 'Kolkata',
    image: 'https://images.pexels.com/photos/9166266/pexels-photo-9166266.jpeg',
    description: 'Historic Gurudwara visited by Guru Tegh Bahadur and Guru Gobind Singh. Features traditional Sikh architecture with green pillars and ancient wooden beams.',
    history: 'Renowned for being visited by the ninth and tenth Sikh Gurus, bestowing the site with profound religious and historical importance.',
    architecture: 'Traditional Sikh design with square hall, multiple entrances, green-colored royal pillars, and ancient wooden beams supporting the ceiling.',
    significance: 'Revered place of worship with rich spiritual heritage, adjacent to Gurudwara Bara Sikh Sangat.',
    
    openTimings: '4:00 AM - 10:00 PM',
    prayerTimings: 'Morning and Evening prayers',
    amenities: ['Prayer Hall', 'Community Services'],
    festivals: ['Guru Nanak Jayanti', 'Guru Gobind Singh Jayanti', 'Baisakhi'],
    education: ['Sikh History', 'Gurbani Studies'],
    daanDakshina: ['Community Donations', 'Seva Contributions'],
    foodForDevotees: 'Community kitchen services',
    
    location: {
      coordinates: '22.5734°N 88.3630°E',
      googleMapsLink: 'https://maps.google.com/?q=Gurudwara+Chhota+Sikh+Sangat+Kolkata',
      weather: 'Tropical wet and dry climate',
      seaLevel: '9 m (30 ft)'
    },
    howToReach: {
      nearestBus: 'Bara Bazar Bus Stand',
      nearestTrain: 'Howrah Junction (4 km)',
      nearestAirport: 'Netaji Subhas Chandra Bose International Airport (20 km)'
    },
    nearbyRestaurants: ['Local Vegetarian Restaurants'],
    hotels: {
      luxury: ['Nearby Kolkata Hotels'],
      budget: ['Budget Accommodations']
    },
    nearbyAttractions: {
      religious: ['Gurudwara Bara Sikh Sangat', 'Other Religious Sites'],
      nonReligious: ['Bara Bazar Market', 'Historical Sites']
    },
    famousLocalFood: ['Punjabi Cuisine', 'Vegetarian Dishes'],
    contactDetails: {
      address: '112 Cotton Street, Raja Katra, Bara Bazar, Jorasanko, Kolkata 700007'
    }
  }
];